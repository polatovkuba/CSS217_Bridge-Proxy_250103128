class SmartLight implements Device {
    public void turnOn() {
        System.out.println("Smart Light glows bright white.");
    }

    public void turnOff() {
        System.out.println("Smart Light shuts off.");
    }

    public void setVolume(int level) {
        System.out.println("Smart Light brightness set to: " + level + "%");
    }
}

public class Main {
    public static void main(String[] args) {
        Device light = new SmartLight();
        AdvancedRemote remote = new AdvancedRemote(light);
        remote.powerOn();
        remote.mute();
    }
}