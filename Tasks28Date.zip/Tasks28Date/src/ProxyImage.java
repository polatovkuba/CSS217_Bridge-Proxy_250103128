class ProxyImage implements Image {
    RealImage realImage;
    String fileName;
    String userRole;

    public ProxyImage(String fileName, String userRole) {
        this.fileName = fileName;
        this.userRole = userRole;
    }

    public void show() {
        if (!"ADMIN".equals(userRole)) {
            System.out.println("[ACCESS DENIED] You lack permission to view: " + fileName);
            return;
        }
        if (realImage == null) {
            realImage = new RealImage(fileName);
        }
        realImage.show();
    }
}

public class Main {
    public static void main(String[] args) {
        Image guestProxy = new ProxyImage("salary_sheet.png", "GUEST");
        Image adminProxy = new ProxyImage("salary_sheet.png", "ADMIN");

        guestProxy.show();
        adminProxy.show();
    }
}